﻿using DataGridViewButtonLibrary;
using SqlDataOperations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamBaseLibrary;

namespace DataGridViewButtonExample
{
    public partial class Form1 : Form
    {
        private BindingSource bsCustomers = new BindingSource();
        private Operations ops = new Operations();
        private string removeButtonName = "Remove";
        private int mIdentifier = 0;

        public Form1()
        {
            InitializeComponent();
            Shown += Form1_Shown;
            var test = new Demo();
            test.Example();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            bsCustomers.DataSource = ops.LoadCustomer2();

            if (!ops.HasException)
            {
                bsCustomers.PositionChanged += BsCustomers_PositionChanged;
                dataGridView1.DataSource = bsCustomers;
                dataGridView1.CreateUnboundButtonColumn(removeButtonName,"Action");
                dataGridView1.KeyDown += DataGridView1_KeyDown;
                dataGridView1.CellContentClick += DataGridView1_CellContentClick;
                dataGridView1.CellEnter += DataGridView1_CellEnter;
                dataGridView1.CellLeave += DataGridView1_CellLeave;
                dataGridView1.Sorted += DataGridView1_Sorted;
                dataGridView1.AdjustButtons(removeButtonName);
            }
            else
            {
                MessageBox.Show($"Failed to load customers:{Environment.NewLine}{ops.LastException.Message}");
            }
        }
        /// <summary>
        /// Two things happen here.
        /// First we re-position to the current row
        /// Secondly re-adjust the buttons as done in form shown event so only the current
        /// row button is visible.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridView1_Sorted(object sender, EventArgs e)
        {
            bsCustomers.Position = bsCustomers.Find("CustomerIdentifier", mIdentifier);
            dataGridView1.AdjustButtons(removeButtonName);
        }
        /// <summary>
        /// Remember the current DataRow primary key which is used
        /// in DataGridView1_Sorted event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BsCustomers_PositionChanged(object sender, EventArgs e)
        {
            if (bsCustomers.Current != null)
            {
                mIdentifier = bsCustomers.CurrentRow().Field<int>("CustomerIdentifier");
            }
        }
        private void DataGridView1_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewDisableButtonCell buttonCell = (DataGridViewDisableButtonCell)(dataGridView1.Rows[e.RowIndex].Cells[removeButtonName]);
            buttonCell.Enabled = false;
            dataGridView1.Invalidate();
        }
        private void DataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewDisableButtonCell buttonCell = (DataGridViewDisableButtonCell)(dataGridView1.Rows[e.RowIndex].Cells[removeButtonName]);

            buttonCell.Enabled = true;

            if (buttonCell.Value == null)
            {
                buttonCell.Value = removeButtonName;
            }

            dataGridView1.Invalidate();
        }
        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.IsHeaderButtonCell(e))
            {
                PromptToRemoveCurrentRecordInDataGridViewFromBindingSource(dataGridView1);
            }
        }
        private void DataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dataGridView1.DetailsButtonIsValid(removeButtonName))
                {
                    PromptToRemoveCurrentRecordInDataGridViewFromBindingSource(dataGridView1);
                    e.Handled = true;
                }
            }
        }
        public void PromptToRemoveCurrentRecordInDataGridViewFromBindingSource(DataGridView GridView)
        {
            if (dataGridView1.DetailsButtonIsValid(removeButtonName))
            {
                if (KarenDialogs.Question($"Remove '{bsCustomers.CurrentRow().Field<string>("CompanyName")}'"))
                {
                    if (ops.FakeRemoveCustomer(bsCustomers.CurrentRow().Field<int>("CustomerIdentifier")))
                    {
                        bsCustomers.RemoveCurrent();
                    }
                }
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
