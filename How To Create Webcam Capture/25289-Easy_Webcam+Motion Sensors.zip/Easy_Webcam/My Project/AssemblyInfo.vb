﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows
Imports System.Drawing

<Assembly: AssemblyTitle("Easy_Webcam")> 
<Assembly: AssemblyDescription("Easy Webcam Capture")> 
<Assembly: AssemblyCompany("KingdomVirtual.com")> 
<Assembly: AssemblyProduct("Easy_Webcam")> 
<Assembly: AssemblyCopyright("Copyright © 2010-2011, Albert Sandro Mamu")> 
<Assembly: AssemblyTrademark("The KingdomVirtual's")> 

<Assembly: ComVisible(False)>
<Assembly: Guid("adf1a6bf-352c-4a4b-bef4-803d540c3eae")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
